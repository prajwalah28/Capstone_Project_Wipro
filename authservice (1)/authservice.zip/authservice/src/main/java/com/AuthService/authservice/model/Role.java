package com.AuthService.authservice.model;

public enum Role {
        USER,
	    ADMIN
}
