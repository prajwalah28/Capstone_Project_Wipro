# Bank Management System - Authentication Setup

This document provides a comprehensive guide to the token-based authentication system implemented in the Angular Bank Management Frontend.

## 🚀 Features Implemented

### Authentication System
- **JWT Token Management**: Secure token storage and validation
- **Username-based Authentication**: Uses username instead of email
- **Role-Based Access Control**: User roles (USER, ADMIN, MANAGER)
- **Route Protection**: Guards for protected routes
- **HTTP Interceptor**: Automatic token injection in requests

### Components
- **Login Component**: Beautiful login form with username/password validation
- **Register Component**: User registration with username, password, and role selection
- **Dashboard Component**: User information display and role testing
- **Auth Guard**: Route protection based on authentication status
- **Role Guard**: Route protection based on user roles

## 📁 File Structure

```
src/app/
├── core/
│   ├── models/
│   │   └── auth.model.ts              # Authentication interfaces and types
│   ├── services/
│   │   ├── auth.service.ts            # Main authentication service
│   │   └── token.service.ts           # JWT token management
│   ├── interceptors/
│   │   └── auth.interceptor.ts        # HTTP interceptor for token injection
│   └── guards/
│       └── auth.guard.ts              # Route protection guards
├── modules/
│   ├── auth/
│   │   ├── login/
│   │   │   ├── login.component.ts     # Login component logic
│   │   │   ├── login.component.html   # Login form template
│   │   │   └── login.component.css    # Login styling
│   │   └── register/
│   │       ├── register.component.ts  # Register component logic
│   │       ├── register.component.html # Register form template
│   │       └── register.component.css  # Register styling
│   └── dashboard/
│       └── dashboard/
│           ├── dashboard.component.ts  # Dashboard with user info
│           ├── dashboard.component.html # Dashboard template
│           └── dashboard.component.css # Dashboard styling
├── environments/
│   ├── environment.ts                 # Development environment config
│   └── environment.prod.ts           # Production environment config
└── app.config.ts                      # App configuration with HTTP client
```

## 🔧 Setup Instructions

### 1. Backend API Configuration

The API URL is configured in `src/environments/environment.ts`:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8081'
};
```

### 2. Backend Endpoints Required

Your backend should implement these endpoints:

```
POST /auth/login
POST /auth/register
```

### 3. Expected API Responses

#### Login Request
```json
{
  "username": "root5",
  "password": "root5"
}
```

#### Login Response
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyb290NSIsInJvbGUiOiJVU0VSIiwidXNlcklkIjozLCJpYXQiOjE3NTY2MjkyMjUsImV4cCI6MTc1NjYzMjgyNX0.WSIOqBA2bf6PKZX23B7WVzq0eUFmvOFVw2QsOXrRbKc"
}
```

#### Register Request
```json
{
  "username": "root6",
  "password": "root6",
  "role": "ADMIN"
}
```

#### Register Response
```json
{
  "message": "User registered successfully",
  "success": true
}
```

## 🛡️ Security Features

### Token Management
- **Secure Storage**: Tokens stored in localStorage
- **Token Validation**: JWT payload validation and expiration checking
- **Logout Cleanup**: Complete token cleanup on logout
- **No Refresh Tokens**: Simple token-based authentication

### Route Protection
- **Authentication Guard**: Protects routes requiring login
- **Role-Based Guard**: Protects routes based on user roles
- **Automatic Redirects**: Redirects to login page when unauthorized

### HTTP Interceptor
- **Automatic Token Injection**: Adds Authorization header to all requests
- **Error Handling**: Proper error handling and user logout on auth failures
- **401 Handling**: Logs out user on 401 unauthorized responses

## 🎨 UI Features

### Login Form
- Modern gradient background
- Username/password validation
- Loading states with spinner
- Responsive design
- Beautiful animations

### Register Form
- Complete registration form with username, password, and role selection
- Password confirmation validation
- Role dropdown with USER, ADMIN, MANAGER options
- Success/error message handling

### Dashboard
- User information display with username
- Authentication status indicators
- Role permission display
- Logout functionality

## 🔐 Usage Examples

### Protecting Routes

```typescript
// In your routing module
const routes: Routes = [
  { 
    path: 'dashboard', 
    component: DashboardComponent, 
    canActivate: [authGuard] 
  },
  { 
    path: 'admin', 
    component: AdminComponent, 
    canActivate: [roleGuard(['ADMIN'])] 
  }
];
```

### Checking Authentication Status

```typescript
// In any component
constructor(private authService: AuthService) {}

ngOnInit() {
  if (this.authService.isAuthenticated()) {
    // User is logged in
    const user = this.authService.getCurrentUser();
    console.log('Current user:', user);
  }
}
```

### Checking User Roles

```typescript
// Check specific role
if (this.authService.hasRole('ADMIN')) {
  // User has admin role
}

// Check multiple roles
if (this.authService.hasAnyRole(['ADMIN', 'MANAGER'])) {
  // User has admin or manager role
}
```

### Making Authenticated Requests

```typescript
// The interceptor automatically adds the token
this.http.get('/api/accounts').subscribe(response => {
  // Request includes Authorization header
});
```

## 🚀 Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   ng serve
   ```

3. **Access the Application**
   - Open `http://localhost:4200`
   - Navigate to `/auth/login` or `/auth/register`

4. **Test with Your Backend**
   - Use the provided test credentials:
     - Username: `root5`, Password: `root5`
     - Or register a new user with role selection

## 🔧 Customization

### Styling
- Update CSS variables in component stylesheets
- Modify color schemes and gradients
- Adjust responsive breakpoints

### Validation
- Add custom validators to forms
- Modify error messages
- Add additional form fields

### Security
- Implement CSRF protection
- Add rate limiting
- Use httpOnly cookies instead of localStorage

## 📝 Notes

- The current implementation uses localStorage for token storage
- For production, consider using httpOnly cookies for better security
- Implement proper error handling for network failures
- Add loading states for better user experience
- The system supports USER, ADMIN, and MANAGER roles
- Username-based authentication instead of email-based

## 🤝 Contributing

1. Follow the existing code structure
2. Add proper TypeScript types
3. Include error handling
4. Add unit tests for new features
5. Update documentation

## 📄 License

This project is part of the Bank Management System.
