export const environment = {
  production: true,
  apiUrl: 'https://your-production-api.com' // Update with your production API URL
};
