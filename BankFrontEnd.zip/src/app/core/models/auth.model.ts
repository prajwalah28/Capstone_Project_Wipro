export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  role: UserRole;
}

export interface RegisterResponse {
  message: string;
  success: boolean;
}

export interface User {
  id: number;
  username: string;
  role: UserRole;
  isActive: boolean;
  createdAt?: Date;
  lastLoginAt?: Date;
}

export enum UserRole {
  USER = 'USER',
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER'
}

export interface TokenPayload {
  sub: string; // username
  role: UserRole;
  userId: number;
  iat: number; // issued at
  exp: number; // expiration
}

export interface RefreshTokenRequest {
  token: string;
}

export interface RefreshTokenResponse {
  token: string;
}
