import { TokenService } from './token.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private apiUrl = 'http://localhost:8080/api/customers';

  constructor(private http: HttpClient, private TokenService: TokenService) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.TokenService.getToken();
    return new HttpHeaders({
      Authorization: token ? `Bearer ${token}` : ''
    });
  }

  // ✅ Create new customer
  createCustomer(customerData: any): Observable<any> {
    return this.http.post(this.apiUrl, customerData, {
      headers: this.getAuthHeaders()
    });
  }

  // ✅ Get customer accounts by userId
  getCustomersByUser(userId: number, token: string): Observable<any> {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`, // send user token
    });
    return this.http.get(`${this.apiUrl}/user/${userId}`, { headers });
  }
}
