import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { LoginRequest, LoginResponse, User, RegisterRequest, RegisterResponse } from '../models/auth.model';
import { TokenService } from './token.service';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = `${environment.apiUrl}/auth`;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private tokenService: TokenService,
    private router: Router
  ) {
    // Initialize current user from stored data
    this.initializeUser();
  }

  private initializeUser(): void {
  const user = this.tokenService.getUser();

  if (user && !this.tokenService.isTokenExpired()) {
    this.currentUserSubject.next(user);

  } else if (this.tokenService.hasToken() && !this.tokenService.isTokenExpired()) {
    // Create user object from token payload
    const payload = this.tokenService.getTokenPayload();
    if (payload) {
      const user: User = {
        id: payload.userId,
        username: payload.sub,
        role: payload.role,
        isActive: true
      };
      this.currentUserSubject.next(user);
      this.tokenService.setToken(this.tokenService.getToken()!, user);
    }

  } else {
    // ❌ currently calls logout()
    // this.logout();

    // ✅ instead, just clear current user but don't force logout
    this.currentUserSubject.next(null);
  }
}


  // Login method
  login(loginRequest: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.API_URL}/login`, loginRequest)
      .pipe(
        tap(response => {
          // Create user object from token payload
          const payload = this.tokenService.decodeToken(response.token);
          const user: User = {
            id: payload.userId,
            username: payload.sub,
            role: payload.role,
            isActive: true
          };
          
          this.tokenService.setToken(response.token, user);
          this.currentUserSubject.next(user);
        }),
        catchError(error => {
          console.error('Login error:', error);
          return throwError(() => error);
        })
      );
  }

  // Register method
  register(registerRequest: RegisterRequest): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>(`${this.API_URL}/register`, registerRequest)
      .pipe(
        catchError(error => {
          console.error('Registration error:', error);
          return throwError(() => error);
        })
      );
  }

  // Logout method
  logout(): void {
    this.tokenService.clearTokens();
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/login']);
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return this.tokenService.hasToken() && !this.tokenService.isTokenExpired();
  }

  // Get current user
  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  // Get user role
  getUserRole(): string {
    const payload = this.tokenService.getTokenPayload();
    return payload?.role || '';
  }

  // Check if user has specific role
  hasRole(role: string): boolean {
    return this.tokenService.hasRole(role);
  }

  // Check if user has any of the specified roles
  hasAnyRole(roles: string[]): boolean {
    return this.tokenService.hasAnyRole(roles);
  }

  // Get authorization header
  getAuthHeaders(): HttpHeaders {
    const token = this.tokenService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  // Get username
  getUsername(): string | null {
    return this.tokenService.getUsername();
  }

  // Get user ID
  getUserId(): number | null {
    return this.tokenService.getUserId();
  }
}
