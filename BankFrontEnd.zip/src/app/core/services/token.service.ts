import { Injectable } from '@angular/core';
import { TokenPayload } from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  private readonly TOKEN_KEY = 'access_token';
  private readonly USER_KEY = 'user';

  constructor() { }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Store token and user data
  setToken(token: string, user?: any): void {
    if (this.isBrowser()) {
      localStorage.setItem(this.TOKEN_KEY, token);
      if (user) {
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
      }
    }
  }

  // Get access token
  getToken(): string | null {
    return this.isBrowser() ? localStorage.getItem(this.TOKEN_KEY) : null;
  }

  // Get user data
  getUser(): any {
    if (!this.isBrowser()) return null;
    const userStr = localStorage.getItem(this.USER_KEY);
    return userStr ? JSON.parse(userStr) : null;
  }

  // Clear all tokens and user data
  clearTokens(): void {
    if (this.isBrowser()) {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    }
  }

  // Check if token exists
  hasToken(): boolean {
    return !!this.getToken();
  }

  // Check if token is expired
  isTokenExpired(): boolean {
    const token = this.getToken();
    if (!token) return true;

    try {
      const payload = this.decodeToken(token);
      const currentTime = Date.now() / 1000;
      return payload.exp < currentTime;
    } catch (error) {
      return true;
    }
  }

  // Decode JWT token
  decodeToken(token: string): TokenPayload {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64).split('').map(c =>
          '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
        ).join('')
      );
      return JSON.parse(jsonPayload);
    } catch (error) {
      throw new Error('Invalid token');
    }
  }

  // Get token payload
  getTokenPayload(): TokenPayload | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      return this.decodeToken(token);
    } catch (error) {
      return null;
    }
  }

  // Check if user has specific role
  hasRole(role: string): boolean {
    const payload = this.getTokenPayload();
    return payload?.role === role;
  }

  // Check if user has any of the specified roles
  hasAnyRole(roles: string[]): boolean {
    const payload = this.getTokenPayload();
    return payload ? roles.includes(payload.role) : false;
  }

  // Get username from token
  getUsername(): string | null {
    const payload = this.getTokenPayload();
    return payload?.sub || null;
  }

  // Get user ID from token
  getUserId(): number | null {
    const payload = this.getTokenPayload();
    return payload?.userId || null;
  }
}
