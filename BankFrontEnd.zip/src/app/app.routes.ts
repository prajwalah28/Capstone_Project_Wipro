import { Routes } from '@angular/router';

// Components
import { LoginComponent } from './modules/auth/login/login.component';
import { RegisterComponent } from './modules/auth/register/register.component';
import { DashboardComponent } from './modules/dashboard/dashboard/dashboard.component';
import { CustomerComponent } from './modules/customers/customers.component';
import { AccountComponent } from './modules/account/account.component';
import { TransactionComponent } from './modules/transaction/transaction.component';
import { CreateAccountComponent } from './modules/create-account/create-account.component';
import { CardComponent } from './shared/shared/components/card/card.component';

// Guards
import { authGuard, roleGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  // 🔹 Auth routes
  {
    path: 'auth',
    children: [
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent }
    ]
  },

  // 🔹 Public routes
  { path: 'home', component: CardComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  // 🔹 Protected (authenticated) routes
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [authGuard]
  },

  // 🔹 User-only routes
  {
    path: 'customers/create',
    component: CustomerComponent,
    canActivate: [roleGuard(['USER'])]
  },
  {
    path: 'account',
    component: AccountComponent,
    canActivate: [roleGuard(['USER'])]
  },
  {
    path: 'transaction',
    component: TransactionComponent,
    canActivate: [roleGuard(['USER'])]
  },

  // 🔹 Admin-only routes
  {
    path: 'create-account',
    component: CreateAccountComponent,
    canActivate: [roleGuard(['ADMIN'])]
  },

  // 🔹 Fallback / wildcard
  { path: '**', redirectTo: '/home' }
];
