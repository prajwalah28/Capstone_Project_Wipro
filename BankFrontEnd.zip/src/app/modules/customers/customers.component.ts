import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CustomerService } from '../../core/services/customer.service';

@Component({
  selector: 'app-customer',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomerComponent {
  newCustomer = { name: '', email: '', phone: '' };
  customers: any[] = [];
  userId: number = 3;
  token: string = '';

  loading: boolean = false;   // 👈 Added loading state

  constructor(private customerService: CustomerService) {}

  ngOnInit() {
    this.token = localStorage.getItem('token') || '';
  }

  // ✅ Create Customer logic
  createCustomer(): void {
    if (!this.newCustomer.name || !this.newCustomer.email || !this.newCustomer.phone) {
      alert('Please fill all fields');
      return;
    }

    this.loading = true; // show spinner
    this.customerService.createCustomer(this.newCustomer).subscribe({
      next: (res) => {
        alert('Customer created successfully!');
        console.log('Created:', res);
        this.newCustomer = { name: '', email: '', phone: '' };
      },
      error: (err) => {
        console.error('Error creating customer', err);
        alert('Failed to create customer');
      },
      complete: () => {
        this.loading = false; // hide spinner
      }
    });
  }

  // ✅ Show All Customers logic
  showAllCustomers(): void {
    this.loading = true; // show spinner
    this.customerService.getCustomersByUser(this.userId, this.token).subscribe({
      next: (res) => {
        this.customers = res;
      },
      error: (err) => {
        console.error('Error loading customers:', err);
      },
      complete: () => {
        this.loading = false; // hide spinner
      }
    });
  }
}
