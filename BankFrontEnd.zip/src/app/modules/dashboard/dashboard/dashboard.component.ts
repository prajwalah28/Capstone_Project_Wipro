import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { User } from '../../../core/models/auth.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  isAuthenticated = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.checkAuthStatus();
  }

  private checkAuthStatus(): void {
    this.isAuthenticated = this.authService.isAuthenticated();
    this.currentUser = this.authService.getCurrentUser();
    
    if (!this.isAuthenticated) {
      this.router.navigate(['/auth/login']);
    }
  }

  logout(): void {
    this.authService.logout();
  }

  getUserRole(): string {
    return this.authService.getUserRole();
  }

  hasRole(role: string): boolean {
    return this.authService.hasRole(role);
  }

  goToCreateCustomer(): void {
    this.router.navigate(['/customers/create']);
  }

  goToAccounts() {
    this.router.navigate(['/account']);
  }
   goToTransaction() {
    this.router.navigate(['/transaction']);
  }

   goToCreateAccount() {
    this.router.navigate(['/create-account']);
  }
}
