import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountService } from '../../core/services/account.service';

@Component({
  selector: 'app-account',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent {
  accounts: any[] = [];
  token: string = '';
  loading: boolean = false; // ✅ loading state

  constructor(private accountService: AccountService) {}

  ngOnInit() {
    this.token = localStorage.getItem('token') || '';
  }

  // Show all accounts for logged-in user
  showMyAccounts() {
    this.loading = true; // start loading
    this.accountService.getMyAccounts(this.token).subscribe({
      next: (res) => {
        this.accounts = res;
        this.loading = false; // stop loading
      },
      error: (err) => {
        console.error('Error fetching accounts:', err);
        this.loading = false; // stop loading on error
      }
    });
  }
}
