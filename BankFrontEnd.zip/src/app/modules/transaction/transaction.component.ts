import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TransactionService } from '../../core/services/transaction.service';

@Component({
  selector: 'app-transaction',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent {
  fromAccountId: number | null = null;
  toAccountId: number | null = null;
  amount: number | null = null;
  customerId: number | null = null;
  token: string = '';

  message: string = '';
  transactionResponse: any = null;
  loading: boolean = false;   // 👈 for loading state

  constructor(private transactionService: TransactionService) {}

  ngOnInit() {
    this.token = localStorage.getItem('token') || '';
    this.customerId = Number(localStorage.getItem('customerId')) || null;
  }

  doTransfer() {
    if (!this.fromAccountId || !this.toAccountId || !this.amount || !this.customerId) {
      this.message = '⚠️ Please fill all fields before transfer.';
      return;
    }

    this.loading = true;  // 👈 start loading
    this.transactionResponse = null;
    this.message = '';

    this.transactionService
      .transfer(this.fromAccountId, this.toAccountId, this.amount, this.customerId, this.token)
      .subscribe({
        next: (res) => {
          this.loading = false;  // 👈 stop loading
          this.transactionResponse = res;
          this.message = '✅ Transfer completed successfully!';
        },
        error: (err) => {
          this.loading = false;  // 👈 stop loading
          console.error('Transfer Error:', err);
          this.message = '❌ Transfer failed. Please try again.';
        }
      });
  }
}
