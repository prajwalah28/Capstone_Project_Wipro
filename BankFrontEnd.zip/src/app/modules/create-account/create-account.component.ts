import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AccountService } from '../../core/services/account.service';

@Component({
  selector: 'app-create-account',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {
  accountData = {
    customerId: null,
    accountNumber: '',
    accountType: '',
    balance: null
  };

  token: string = '';
  message: string = '';
  createdAccount: any = null;

  constructor(private accountService: AccountService) {}

  ngOnInit() {
    this.token = localStorage.getItem('token') || ''; // admin token stored at login
  }

  createAccount() {
    if (!this.accountData.customerId || !this.accountData.accountNumber || !this.accountData.accountType || !this.accountData.balance) {
      this.message = '⚠️ Please fill all fields';
      return;
    }

    this.accountService.createAccount(this.accountData, this.token).subscribe({
      next: (res) => {
        console.log('Account Created:', res);
        this.createdAccount = res;
        this.message = '✅ Account created successfully!';
        this.accountData = { customerId: null, accountNumber: '', accountType: '', balance: null }; // reset form
      },
      error: (err) => {
        console.error('Error creating account:', err);
        this.message = '❌ Failed to create account';
      }
    });
  }
}
